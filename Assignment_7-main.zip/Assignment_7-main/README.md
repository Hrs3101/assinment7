# Assignment_7![Simulator Screen Shot - iPhone 6s - 2021-12-09 at 17 12 15](https://user-images.githubusercontent.com/63149524/145390766-410319c5-d96f-48d7-9118-f986b40b3788.png)![Simulator Screen Shot - iPhone 6s - 2021-12-09 at 17 12 27](https://user-images.githubusercontent.com/63149524/145390774-f534ab4b-2b04-4304-bd4c-ecf61365d694.png)

![Simulator Screen Shot - iPhone 6s - 2021-12-09 at 17 12 23](https://user-images.githubusercontent.com/63149524/145390769-46210517-fea7-4e75-9830-a37b8588f9b3.png)
![Simulator Screen Shot - iPhone 6s - 2021-12-09 at 17 12 34](https://user-images.githubusercontent.com/63149524/145390778-e9393719-999c-4a73-8591-93d5afe153d5.png)
